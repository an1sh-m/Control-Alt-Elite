/**
 * This work is marked with CC0 1.0 Universal
 */
package shapes;

public class Square extends Rectangle {
    public Square(Point centre, double side) {
        super(centre, side, side);
    }

}
